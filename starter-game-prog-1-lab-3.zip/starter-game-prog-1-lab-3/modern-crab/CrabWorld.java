// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import greenfoot.*;

/**
 * Write a description of class CrabWorld here. @author (your name) @version (a version number or a date)
 */
public class CrabWorld extends World
{

    /* (World, Actor, GreenfootImage, Greenfoot and MouseInfo)*/

    /**
     * Constructor for objects of class CrabWorld.
     */
    public CrabWorld()
    {
        super(560, 560, 1);
        prepare();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Crab crab =  new Crab();
        addObject(crab, 127, 411);
        worm worm =  new worm();
        addObject(worm, 209, 110);
        worm worm2 =  new worm();
        addObject(worm2, 150, 203);
        worm worm3 =  new worm();
        addObject(worm3, 112, 114);
        worm worm4 =  new worm();
        addObject(worm4, 478, 99);
        worm worm5 =  new worm();
        addObject(worm5, 437, 319);
        worm worm6 =  new worm();
        addObject(worm6, 354, 216);
        worm worm7 =  new worm();
        addObject(worm7, 352, 110);
        worm worm8 =  new worm();
        addObject(worm8, 258, 61);
        worm worm9 =  new worm();
        addObject(worm9, 351, 345);
        worm worm10 =  new worm();
        addObject(worm10, 418, 480);
        worm worm11 =  new worm();
        addObject(worm11, 457, 490);
        worm worm12 =  new worm();
        addObject(worm12, 325, 485);
        worm worm13 =  new worm();
        addObject(worm13, 239, 348);
        worm worm14 =  new worm();
        addObject(worm14, 468, 221);
        worm worm15 =  new worm();
        addObject(worm15, 385, 31);
        worm worm16 =  new worm();
        addObject(worm16, 53, 380);
        worm worm17 =  new worm();
        addObject(worm17, 66, 481);
        worm worm18 =  new worm();
        addObject(worm18, 170, 522);
        worm worm19 =  new worm();
        addObject(worm19, 55, 44);
    }
}

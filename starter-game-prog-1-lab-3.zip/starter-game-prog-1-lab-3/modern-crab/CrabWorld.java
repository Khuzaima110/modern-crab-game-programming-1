// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import greenfoot.*;

/**
 * Write a description of class CrabWorld here. @author (your name) @version (a version number or a date)
 */
public class CrabWorld extends World
{

    /* (World, Actor, GreenfootImage, Greenfoot and MouseInfo)*/

    /**
     * Constructor for objects of class CrabWorld.
     */
    public CrabWorld()
    {
        super(560, 560, 1);
        prepare();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Crab crab =  new Crab();
        addObject(crab, 121, 435);
        worm worm =  new worm();
        addObject(worm, 120, 93);
        worm worm2 =  new worm();
        addObject(worm2, 419, 190);
        worm worm3 =  new worm();
        addObject(worm3, 277, 371);
        worm worm4 =  new worm();
        addObject(worm4, 308, 61);
        worm worm5 =  new worm();
        addObject(worm5, 494, 431);
        lobster lobster =  new lobster();
        addObject(lobster, 465, 50);
    }
}
